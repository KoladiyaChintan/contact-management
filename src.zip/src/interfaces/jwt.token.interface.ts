export interface JwtTokenInterface {
  id: string;
  email: string;
  name: string;
}
