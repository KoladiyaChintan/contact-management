import { Injectable } from '@nestjs/common';
import { JwtTokenInterface } from 'src/interfaces/jwt.token.interface';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class JwtHelper {
  public async generateToken(tokenDto: JwtTokenInterface): Promise<string> {
    const token = jwt.sign(tokenDto, process.env.JWT_SECRET, {
      expiresIn: '60h',
    });
    return token;
  }
}
