import { Inject, Injectable } from '@nestjs/common';
import { ContactList } from 'src/entities/contact-list.entity';
import { ContactListDto } from './dto/contact-list.dto';
import * as jwt from 'jsonwebtoken';
import { UserRegister } from 'src/entities/create-user.entity';

@Injectable()
export class ContactListService {
  constructor(
    @Inject('CONTACT_LIST_REPOSITORY')
    private readonly CONTACT_LIST_REPOSITORY: typeof ContactList,
    @Inject('USER_REGISTRATION_REPOSITORY')
    private readonly USER_REGISTRATION_REPOSITORY: typeof UserRegister,
  ) {}

  async create(req, contactListDto: ContactListDto) {
    // return await this.CONTACT_LIST_REPOSITORY.create(contactListDto);
    const bearerHeader = req.headers.authorization.replace('Bearer', '');
    const jwtData = jwt.verify(bearerHeader, process.env.JWT_SECRET);

    console.log('data', jwtData);
    contactListDto['userid'] = jwtData['id'];
    const get = await this.CONTACT_LIST_REPOSITORY.create(contactListDto);
    try {
      if (get) {
        return { contact: get };
      }
    } catch (err) {
      return err;
    }
  }

  async getall(req) {
    const bearerHeader = req.headers.authorization.replace('Bearer', '');
    const jwtData = jwt.verify(bearerHeader, process.env.JWT_SECRET);

    // console.log('data', jwtData);

    const get = await this.USER_REGISTRATION_REPOSITORY.findAll({
      where: { id: jwtData['id'] },
      attributes: ['name', 'email'],
      include: [
        {
          model: ContactList,
          attributes: ['id', 'name', 'email', 'phonenumber'],
        },
      ],
    });
    // console.log(get);
    return get;
  }

  async update(req, id: string, contactListDto: ContactListDto) {
    const bearerHeader = req.headers.authorization.replace('Bearer', '');
    const jwtData = jwt.verify(bearerHeader, process.env.JWT_SECRET);

    const get = await this.CONTACT_LIST_REPOSITORY.update(contactListDto, {
      where: { id },
    });
    return { msg: 'Update successfully', get };
  }

  async delete(req, id: string) {
    const bearerHeader = req.headers.authorization.replace('Bearer', '');
    const jwtData = jwt.verify(bearerHeader, process.env.JWT_SECRET);

    const get = await this.CONTACT_LIST_REPOSITORY.destroy({ where: { id } });
    return { msg: 'Delete Successfully', get };
  }
}
