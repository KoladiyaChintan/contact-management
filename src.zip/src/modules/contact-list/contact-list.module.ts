import { Module } from '@nestjs/common';
import { ContactListService } from './contact-list.service';
import { ContactListController } from './contact-list.controller';
import { ContactListProvider } from 'src/providers/contact-list.provider';
import { UserRegisterProvider } from 'src/providers/user-registration.providers';

@Module({
  providers: [
    ContactListService,
    ...ContactListProvider,
    ...UserRegisterProvider,
  ],
  controllers: [ContactListController],
})
export class ContactListModule {}
