export class ContactListDto {
  name: string;
  email: string;
  phonenumber: number;
}
