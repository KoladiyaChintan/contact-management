import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Req,
} from '@nestjs/common';
import { Request } from 'express';
import { ContactListService } from './contact-list.service';
import { ContactListDto } from './dto/contact-list.dto';

@Controller('contact-list')
export class ContactListController {
  constructor(private readonly contactListService: ContactListService) {}

  @Post('create')
  async create(
    @Req() req: Request,
    @Body() contactListDto: ContactListDto,
  ): Promise<any> {
    return await this.contactListService.create(req, contactListDto);
  }

  @Get('getuser')
  async getuser(@Req() req: Request): Promise<any> {
    return await this.contactListService.getall(req);
  }

  @Put('update/:id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() contactListDto: ContactListDto,
  ): Promise<any> {
    return await this.contactListService.update(req, id, contactListDto);
  }

  @Delete('delete/:id')
  async delete(@Req() req: Request, @Param('id') id: string): Promise<any> {
    return await this.contactListService.delete(req, id);
  }
}
