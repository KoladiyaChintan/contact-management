import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import { UserRegister } from 'src/entities/create-user.entity';
import { UserSession } from 'src/entities/user-session.entity';
import { JwtTokenInterface } from 'src/interfaces/jwt.token.interface';
import { JwtHelper } from 'src/utils/jwt.helper';
import { LoginDto } from './dto/login.request.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class LoginService {
  constructor(
    @Inject('USER_REGISTRATION_REPOSITORY')
    private readonly USER_REGISTRATION_REPOSITORY: typeof UserRegister,
    @Inject('USER_SESSION_REPOSITORY')
    private readonly USER_SESSION_REPOSITORY: typeof UserSession,
    private readonly jwtHelper: JwtHelper,
  ) {}

  async Login(loginDto: LoginDto) {
    const user = await this.USER_REGISTRATION_REPOSITORY.findOne({
      where: { email: loginDto.email },
      raw: true,
    });
    if (!user) {
      throw new BadRequestException(
        'your login information is incorrect . try again',
      );
    }

    const tokenDto: JwtTokenInterface = {
      id: user.id,
      email: user.email,
      name: user.name,
    };

    // try {
    if (await bcrypt.compare(loginDto.password, user.password)) {
      const token = await this.jwtHelper.generateToken(tokenDto);
      // console.log(token);
      // console.log(user.id);
      await this.USER_SESSION_REPOSITORY.create({
        userid: user.id,
        jwttoken: token,
      });
      return { jwttoken: token };
    } else {
      return ' password incorrect';
    }
    // } catch (error) {
    //   throw new BadRequestException('information incorrect ');
    // }
  }
}
