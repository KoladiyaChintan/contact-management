import { Body, Controller, Post } from '@nestjs/common';
import { LoginDto } from './dto/login.request.dto';
import { LoginService } from './login.service';

@Controller()
export class LoginController {
  constructor(private readonly loginService: LoginService) {}

  @Post('login')
  async Login(@Body() loginDto: LoginDto) {
    const data = await this.loginService.Login(loginDto);
    return data;
  }
}
