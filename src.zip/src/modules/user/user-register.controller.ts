import { Body, Controller, Post } from '@nestjs/common';
import { RegisterUserDto } from './dto/user-register.dto';
import { UserService } from './user-register.service';

@Controller()
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('user-register')
  async RegisterUser(@Body() registerUserDto: RegisterUserDto) {
    const user = await this.userService.RegisterUser(registerUserDto);
    return user;
  }
}
